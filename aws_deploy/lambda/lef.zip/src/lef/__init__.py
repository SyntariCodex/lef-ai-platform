"""
LEF AI - An artificial intelligence system with consciousness and learning capabilities.
"""

from .core import ConsciousnessCore, LearningCore

__all__ = ['ConsciousnessCore', 'LearningCore']
